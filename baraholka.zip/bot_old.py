import asyncpg
import logging
import asyncio
import random
from aiogram import Bot, Dispatcher, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

# Подключение к PostgreSQL (замени своими данными!)
DB_URL = "postgresql://postgres:123@localhost:5432/baraholka"

# Создание пула соединений
async def get_db_pool():
    return await asyncpg.create_pool(DB_URL)

# ====== НАСТРОЙКИ ======
TOKEN = "8196226068:AAFfDnp_V3B2E_wGXZVWPbj7grLDwursigc"  # Вставьте токен из BotFather
ADMIN_ID = 8196226068  # Укажите ваш Telegram ID
BANK_CARD = "2202202020202020"  # Номер карты для перевода
pending_payments = {}  # Ожидаемые платежи (user_id: payment_id)

# ====== НАСТРОЙКА ЛОГОВ ======
logging.basicConfig(level=logging.INFO)
bot = Bot(token=TOKEN)
dp = Dispatcher()

# ====== КЛАВИАТУРА ======
kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="➕ Разместить объявление"), KeyboardButton(text="🔍 Найти товар")],
        [KeyboardButton(text="📢 VIP-реклама"), KeyboardButton(text="ℹ️ Помощь")]
    ],
    resize_keyboard=True
)

# ====== ГЛАВНОЕ МЕНЮ ======
@dp.message(lambda message: message.text == "/start")
async def start(message: types.Message):
    await message.answer("👋 Добро пожаловать в *Якутск Барахолка*! Выберите действие:", reply_markup=kb)

# ====== РАЗМЕЩЕНИЕ ОБЪЯВЛЕНИЯ ======
@dp.message(lambda message: message.text == "➕ Разместить объявление")
async def sell_product(message: types.Message):
    await message.answer("Введите товар в формате:\n\n`Название, Категория, Цена, Контакты`")

@dp.message(lambda message: "," in message.text)
async def save_product(message: types.Message):
    data = message.text.split(",")
    if len(data) != 4:
        return await message.answer("❌ Ошибка! Формат: `Название, Категория, Цена, Контакты`.")

    name, category, price, contacts = [d.strip() for d in data]
    user_id = message.from_user.id

    pool = await get_db_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO products (user_id, name, category, price, contacts) VALUES ($1, $2, $3, $4, $5)",
            user_id, name, category, price, contacts
        )
    
    await message.answer(f"✅ Объявление **{name}** добавлено в базу данных!")

# ====== ПОИСК ТОВАРОВ ======
@dp.message(lambda message: message.text == "🔍 Найти товар")
async def search_product(message: types.Message):
    await message.answer("🔎 Введите название товара:")

@dp.message()
async def show_products(message: types.Message):
    keyword = message.text.lower()
    pool = await get_db_pool()

    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT name, price, contacts, is_vip FROM products WHERE LOWER(name) LIKE $1 ORDER BY is_vip DESC, created_at DESC LIMIT 5",
            f"%{keyword}%"
        )

    if not rows:
        return await message.answer("❌ Ничего не найдено.")
    
    result = "🔍 Найдено:\n\n"
    for row in rows:
        star = "🔥 " if row["is_vip"] else ""
        result += f"{star}{row['name']} – {row['price']} ₽\nКонтакты: {row['contacts']}\n\n"

    await message.answer(result)

# ====== VIP-РЕКЛАМА (ОПЛАТА ПЕРЕВОДОМ) ======
@dp.message(lambda message: message.text == "📢 VIP-реклама")
async def promote_product(message: types.Message):
    payment_id = random.randint(10000, 99999)
    user_id = message.from_user.id
    pending_payments[user_id] = payment_id  

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ Оплатить", callback_data=f"pay_transfer_{payment_id}")]
        ]
    )

    await message.answer(
        f"🔥 Хотите продвинуть объявление?\n"
        f"📌 Оплатите **100 ₽** переводом на карту `{BANK_CARD}`.\n"
        f"💳 *Обязательно укажите код платежа: {payment_id}* в комментарии!",
        reply_markup=markup
    )

# ====== ПРИЁМ ФОТО ЧЕКА ======
@dp.message(lambda message: message.photo)
async def receive_payment_receipt(message: types.Message):
    user_id = message.from_user.id
    if user_id not in pending_payments:
        return await message.answer("❌ У вас нет ожидаемых платежей.")

    payment_id = pending_payments[user_id]
    photo = message.photo[-1].file_id  

    caption = f"📝 Новый чек от @{message.from_user.username} (ID: {user_id})\n" \
              f"📌 Код платежа: {payment_id}\n" \
              f"🔍 Проверьте сумму и комментарий в переводе!"

    await bot.send_photo(ADMIN_ID, photo, caption=caption)
    await message.answer("✅ Чек отправлен! Мы проверим и скоро подтвердим VIP-рекламу.")

# ====== ПОДТВЕРЖДЕНИЕ ПЛАТЕЖА (АДМИН) ======
@dp.message(lambda message: message.text.startswith("/confirm"))
async def confirm_payment(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return await message.answer("❌ У вас нет прав для подтверждения платежей.")

    try:
        user_id = int(message.text.split()[1])

        pool = await get_db_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                "UPDATE products SET is_vip = TRUE WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1",
                user_id
            )

        await bot.send_message(user_id, "✅ Ваш платеж подтвержден! Объявление стало VIP.")
        await message.answer(f"👍 Подтверждено для {user_id}")
    except:
        await message.answer("❌ Ошибка! Введите команду в формате: `/confirm ID`.")

# ====== ЗАПУСК БОТА ======
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
